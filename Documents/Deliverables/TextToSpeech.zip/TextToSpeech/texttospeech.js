function playVid() { 
	var audio = document.getElementById("Clip");
        var file=document.getElementById("x");
	var input = document.getElementById("inputTest").value;
	var var2 = input + ".mp3";
	file.setAttribute("src", var2);
	file.setAttribute("type", "audio/mp3");
    audio.load();
    audio.play(); 
} 

function pauseVid() { 
    Clip.pause(); 
} 
