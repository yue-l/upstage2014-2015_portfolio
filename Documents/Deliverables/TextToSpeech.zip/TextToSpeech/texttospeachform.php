
<!DOCTYPE html>
  <head> 
    <title>form</title> 
  </head> 
  <body>
<h1>Text To Speech: Proof of Concept</h1>
<button onclick="pauseVid()" type="button">Pause Video</button><br> 
<label>Enter file names:</label>  <input type="text" name="word" id="inputTest"> 
<button type="button" onclick="playVid()">Submit</button>
<audio id="Clip">
    <source id="x">
  Your browser does not support HTML5 video.
</audio>

</body>
<script type="text/javascript" src="texttospeech.js"> </script> 
<script type="text/javascript">

</script>


</html>