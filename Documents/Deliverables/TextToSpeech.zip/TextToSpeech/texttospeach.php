<!DOCTYPE html>
<html>
<head>
<title>Recive</title>
<!-- 1. skin -->
<link rel="stylesheet" href="//releases.flowplayer.org/5.5.2/skin/minimalist.css">
 
<!-- 2. jquery library -->
<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
 
<!-- 3. flowplayer -->
<script src="//releases.flowplayer.org/5.5.2/flowplayer.min.js"></script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<?php
$word = $_POST["word"];
echo "<p>$word</p>"

?>
<h1>Web Development - Lab x</h1>
 <div class="player" data-ratio="0.4167" >
   <video>
     <source type="video/mp4"  src="<?php echo $word; ?>.mp3">
   </video>
</div>
<script>
// run script after document is ready
$(function () {
 
   // install flowplayer to an element with CSS class "player"
   $(".player").flowplayer({ swf: "/swf/5.5.2/flowplayer.swf" });
   
});
});
</script>
<p>Click <a href="texttospeachform.php">here</a> to go to post.</p>
</body>
</html>