js.jar - Rhino 1.7R4
http://www.mozilla.org/rhino
released under Mozilla Public License 2.0
