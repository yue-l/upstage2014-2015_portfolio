Additional libraries for Apache Ant
===================================

* pyAntTasks.jar - PYTHON ANT TASKS 1.3.3
  http://www.rpstechnologies.net/PyAntTasks.html
  http://code.google.com/p/pyanttasks/
  released under Apache License 2.0

* ant_doxygen.jar - ANT_DOXYGEN-TASK 1.6.1
  http://ant-doxygen.blogspot.com/
  released under Apache License 2.0

* as2ant.jar - AS2ANT 2.2
  https://sourceforge.net/projects/as2lib/
  http://osflash.org/ant
  released under Mozilla Public License 1.1

* yuicompressor-2.4.7.jar - YUI Compressor 2.4.7
  http://yui.github.com/yuicompressor/
  released under BSD license

* yui-compressor-ant-task-0.5.1.jar - YUI Compressor Ant Task 0.5.1
  https://github.com/n0ha/yui-compressor-ant-task/
  http://javaflight.blogspot.de/2008/01/introducing-yui-compressor-ant-task.html
  released an open license (according to the author, see link above)

* ant-contrib-1.0b3.jar - Ant Contrib 1.0 beta3
  http://ant-contrib.sourceforge.net/
  released under the Apache Software License

