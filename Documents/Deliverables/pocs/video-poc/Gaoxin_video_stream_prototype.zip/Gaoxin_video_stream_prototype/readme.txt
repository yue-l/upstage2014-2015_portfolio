1. run index.html with a service, such as Apache, Tomcat and so on
2. accept open webcam requirement,  when the browser requests.

ps: We cannot get the screenshot at first run time. please do not close the browser and run the second time. The screenshot function will work. 

cheers, :)
Gaoxin Huang   
