from flask import url_for, redirect, Flask
import subprocess
app = Flask(__name__)

def textToWav(text):
    subprocess.call(["espeak",text,"-w"+"static/hello.wav"])

@app.route('/')
def hello_world():
    return redirect(url_for('static', filename='test.html'))

@app.route('/<text>')
def test(text):
    textToWav(text)
    return redirect("/")

if __name__ == '__main__':
    app.run(host='0.0.0.0')
