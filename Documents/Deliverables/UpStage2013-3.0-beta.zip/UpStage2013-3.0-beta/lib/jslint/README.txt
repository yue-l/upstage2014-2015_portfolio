https://github.com/mikewest/jslint-utils
